import os 

for i in range(20,67):
	#os.system('cp seds/*.sed inputFiles'+str(i))
	os.system('rm -rf inputFiles'+str(i))
	#os.system('rm run'+str(i))
	#os.system('cp Makefile inputFiles'+str(i))
	print i
