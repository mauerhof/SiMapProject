Taysun Kimm's patch for star formation and stellar feedback.
Patch modified on Dec 1st 2015 to include stuff from the stellar_density patch:

-Stochastic feedback
-Local density at birth and SN explosion

Patch modified on 22 Dec 2016 to include the latest version of mechanical_feedback
- fixed a couple of bugs
- Geen boost
- bpass_v2_300
